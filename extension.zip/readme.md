## Are you tired of all low-quality posts on dou.ua? 

<img width="607" alt="2" src="https://raw.githubusercontent.com/sdwvit/dou-black-list/master/res/2.png">

## Introducing Dou Black List!
( _Chrome Extension for http://dou.ua_ )
## Just install the extension and start banning 🤡 trolls

<img width="607" alt="3" src="https://raw.githubusercontent.com/sdwvit/dou-black-list/master/res/3.png">

### Features include:

- a _very_ convenient button next to the username
- implemented failsafe, so you don't ban someone by accident!
- persistent between reloads, different topics, and threads
- works for collapsed threads
- ban / unban capability
- hides all messages from banned users with an ability to unhide by clicking each of them temporarily (sometimes you just want to see who you banned and pat yourself on the shoulder)
### and much more to come! 

⬇️⬇️⬇️⬇️⬇️⬇️
Installation
------------
Install from [Chrome Web Store](https://chrome.google.com/webstore/detail/dou-black-list/gcpdmbadgmepoeobmjlhifebigahmnbn).

### Special thanks

Guess who was here and is not visible anymore! Thanks to them I got motivated to rewrite this plugin.

<img width="607" alt="1" src="https://raw.githubusercontent.com/sdwvit/dou-black-list/master/res/1.png">
